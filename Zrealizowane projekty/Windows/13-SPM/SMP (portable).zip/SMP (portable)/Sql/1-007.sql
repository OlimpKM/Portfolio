ALTER TABLE [Zadania] RENAME TO [tmp_Zadania];

CREATE TABLE IF NOT EXISTS [Zadania]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [Status] varchar(50) NULL,
  [DataDodania] datetime NOT NULL,
  [DataZmiany] datetime NULL,
  [DataZadania] datetime NOT NULL,
  [DataZakonczenia] datetime NULL,
  [Numer] varchar(150) NULL,
  [NumerZew] varchar(150) NULL,
  [Tytul] varchar(150) NULL,
  [Tresc] text NULL,
  [Tag] text NULL,
  [CzyWazny] integer NOT NULL DEFAULT 0,
  [Blokada] integer NOT NULL DEFAULT 0
);

-- Dopisz z tablicy Zadania
INSERT INTO [Zadania] ([Id],[Status],[DataDodania],[DataZmiany],[DataZadania],[DataZakonczenia],[Numer],[NumerZew],[Tytul],[Tresc],[Tag],[CzyWazny],[Blokada])
SELECT
  t.Id,
  t.Status,
  t.DataDodania,
  null,
  t.DataZadania,
  t.DataZakonczenia,
  t.NumerWew as [Numer],
  t.NumerZew,
  t.Tytul,
  t.Tresc,
  t.Tag,
  0 as [CzyWazny],
  t.Blokada
FROM [tmp_Zadania] AS t;

DROP TABLE IF EXISTS [tmp_Zadania];

UPDATE [Parametry] SET [WartoscS]='1-007' WHERE [Klucz]='Program::WersjaBazy';