ALTER TABLE [Kategorie] RENAME TO [tmp_Kategorie];

CREATE TABLE IF NOT EXISTS [Kategorie]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [Nazwa] varchar(100) NOT NULL,
  [Opis] text NULL,
  [Sciezka] text NULL,
  [CzyDane] int NOT NULL DEFAULT 0,
  [CzyKontakty] int NOT NULL DEFAULT 0,
  [CzyDokumenty] int NOT NULL DEFAULT 0,
  [CzyZdarzenia] int NOT NULL DEFAULT 0,
  [CzyKonta] int NOT NULL DEFAULT 0,
  [CzyRozrachunki] int NOT NULL DEFAULT 0,
  [CzyPrzypomnienia] int NOT NULL DEFAULT 0,
  [CzyUstawienia] int NOT NULL DEFAULT 0,
  [Dane_IdDrzewo] int NULL,
  [Kontakty_IdDrzewo] int NULL,
  [Dokumenty_IdDrzewo] int NULL,
  [Zdarzenia_IdDrzewo] int NULL,
  [Konta_IdDrzewo] int NULL,
  [Rozrachunki_IdDrzewo] int NULL,
  [Przypomnienia_IdDrzewo] int NULL,
  [Ustawienia_IdDrzewo] int NULL,
  [Ikona32] varchar(64) NULL
);

-- Dopisz z tablicy Konta
INSERT INTO [Kategorie] ([Id],[Nazwa],[Opis],[Sciezka],[CzyDane],[CzyKontakty],[CzyDokumenty],[CzyZdarzenia],[CzyKonta],[CzyRozrachunki],[CzyPrzypomnienia],[CzyUstawienia],[Dane_IdDrzewo],[Kontakty_IdDrzewo],[Dokumenty_IdDrzewo],[Zdarzenia_IdDrzewo],[Konta_IdDrzewo],[Rozrachunki_IdDrzewo],[Przypomnienia_IdDrzewo],[Ustawienia_IdDrzewo],[Ikona32])
SELECT
t.Id,
t.Nazwa,
t.Opis,
t.Sciezka,
t.CzyDane,
t.CzyKontakty,
t.CzyDokumenty,
t.CzyZdarzenia,
t.CzyKonta,
t.CzyRozrachunki,
t.CzyPrzypomnienia,
t.CzyUstawienia,
t.Dane_IdDrzewo,
t.Kontakty_IdDrzewo,
t.Dokumenty_IdDrzewo,
t.Zdarzenia_IdDrzewo,
t.Konta_IdDrzewo,
t.Rozrachunki_IdDrzewo,
t.Przypomnienia_IdDrzewo,
t.Ustawienia_IdDrzewo,
t.Ikona32
FROM [tmp_Kategorie] AS t;

DROP TABLE IF EXISTS [tmp_Kategorie];

UPDATE [Parametry] SET [WartoscS]='1-010' WHERE [Klucz]='Program::WersjaBazy';