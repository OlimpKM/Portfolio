ALTER TABLE [Konta] RENAME TO [tmp_Konta];

CREATE TABLE IF NOT EXISTS [Konta]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdKategoria] integer NOT NULL,
  [IdDrzewo] integer NOT NULL,
  [Aktywny] integer NOT NULL DEFAULT 1,
  [Nazwa] varchar(100) NOT NULL,
  [Kraj] varchar(2) NOT NULL,
  [IBAN] varchar(26) NOT NULL,
  [Adresat] text NULL,
  [Tytulem] text NULL,
  [Uwagi] text NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Rozrachunki_IdKategoria FOREIGN KEY([IdKategoria]) REFERENCES Kategoria([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Rozrachunki_IdDrzewo FOREIGN KEY([IdDrzewo]) REFERENCES Drzewo([Id]) ON DELETE RESTRICT
);

-- Dopisz z tablicy Konta
INSERT INTO [Konta] ([Id],[IdKategoria],[IdDrzewo],[Aktywny],[Nazwa],[Kraj],[IBAN],[Adresat],[Tytulem],[Uwagi],[Blokada])
SELECT
  t.Id,
  t.IdKategoria,
  t.IdDrzewo,
  t.Aktywny,
  '?' as [Nazwa],
  t.Kraj,
  t.IBAN,
  t.Adresat,
  t.Tytulem,
  t.Uwagi,
  t.Blokada
FROM [tmp_Konta] AS t;

DROP TABLE IF EXISTS [tmp_Konta];

UPDATE [Parametry] SET [WartoscS]='1-009' WHERE [Klucz]='Program::WersjaBazy';