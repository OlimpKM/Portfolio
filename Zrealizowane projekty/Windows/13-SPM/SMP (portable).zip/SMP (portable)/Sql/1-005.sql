ALTER TABLE [Ustawienia] RENAME TO [tmp_Ustawienia];

CREATE TABLE IF NOT EXISTS [Ustawienia]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdKategoria] integer NOT NULL,
  [IdDrzewo] integer NOT NULL,
  [IdUstawienie] integer NULL,
  [LogowanieZewnetrzne] integer NOT NULL DEFAULT 0,
  [Aktywny] integer NOT NULL DEFAULT 1,
  [Nazwa] varchar(100) NULL,
  [Adres] varchar(300) NULL,
  [Uzytkownik] varchar(300) NULL,
  [Haslo] varchar(300) NULL,
  [DaneA] text NULL,
  [DaneB] text NULL,
  [DaneC] text NULL,
  [DaneD] text NULL,
  [Opis] text NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Ustawienia_IdKategoria FOREIGN KEY([IdKategoria]) REFERENCES Kategoria([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Ustawienia_IdDrzewo FOREIGN KEY([IdDrzewo]) REFERENCES Drzewo([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Ustawienia_IdUstawienie FOREIGN KEY([IdUstawienie]) REFERENCES Ustawienia([Id]) ON DELETE RESTRICT
);

INSERT INTO [Ustawienia]([Id],[IdKategoria],[IdDrzewo],[IdUstawienie],[LogowanieZewnetrzne],[Aktywny],[Nazwa],[Adres],[Uzytkownik],[Haslo],[DaneA],[DaneB],[DaneC],[DaneD],[Opis],[Blokada])
SELECT [Id],[IdKategoria],[IdDrzewo],[IdUstawienie],[LogowanieZewnetrzne],1,[Nazwa],[Adres],[Uzytkownik],[Haslo],[DaneA],[DaneB],[DaneC],[DaneD],[Opis],[Blokada]
FROM [tmp_Ustawienia];

DROP TABLE IF EXISTS [tmp_Ustawienia];

UPDATE [Parametry] SET [WartoscS]='1-005' WHERE [Klucz]='Program::WersjaBazy';