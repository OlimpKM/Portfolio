-- Utworz tablicę Linki
CREATE TABLE IF NOT EXISTS [Linki]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdDokument] integer NULL,
  [IdZdarzenie] integer NULL,
  [IdDane] integer NULL,
  [Tytul] varchar(200) NULL,
  [Rodzaj] varchar(50) NOT NULL,
  [Adres] text NOT NULL
);

-- Dopisz z tablicy Dokumenty
INSERT INTO [Linki] ([IdDokument],[IdZdarzenie],[IdDane],[Tytul],[Rodzaj],[Adres])
SELECT
  t.Id as [IdDokument],
  null as [IdZdarzenie],
  null as [IdDane],
  null as [Tytul],
  'file' as [Rodzaj],
  t.PlikZew as [Adres]
FROM [Dokumenty] AS t
WHERE
  (t.PlikZew IS NOT NULL);

-- Dopisz z tablicy Zdarzenia
INSERT INTO [Linki] ([IdDokument],[IdZdarzenie],[IdDane],[Tytul],[Rodzaj],[Adres])
SELECT
  null as [IdDokument],
  t.Id as [IdZdarzenie],
  null as [IdDane],
  null as [Tytul],
  'file' as [Rodzaj],
  t.PlikZew as [Adres]
FROM [Zdarzenia] AS t
WHERE
  (t.PlikZew IS NOT NULL);

-- Dopisz z tablicy Dane
INSERT INTO [Linki] ([IdDokument],[IdZdarzenie],[IdDane],[Tytul],[Rodzaj],[Adres])
SELECT
  null as [IdDokument],
  null as [IdZdarzenie],
  t.Id as [IdDane],
  null as [Tytul],
  'file' as [Rodzaj],
  t.PlikZew as [Adres]
FROM [Dane] AS t
WHERE
  (t.PlikZew IS NOT NULL);

-- Tablica Dokumenty
ALTER TABLE [Dokumenty] RENAME TO [tmp_Dokumenty];

-- DROP TABLE Dokumenty
CREATE TABLE IF NOT EXISTS [Dokumenty]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdKategoria] integer NOT NULL,
  [IdDrzewo] integer NOT NULL,
  [Aktywny] integer NOT NULL DEFAULT 1,
  [DataDokumentu] datetime NULL,
  [Numer] varchar(50) NULL,
  [Opis] text NULL,
  [Kwota] real NULL,
  [DaneA] text NULL,
  [DaneB] text NULL,
  [DaneC] text NULL,
  [DaneD] text NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Dokumenty_IdKategoria FOREIGN KEY([IdKategoria]) REFERENCES Kategoria([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Dokumenty_IdDrzewo FOREIGN KEY([IdDrzewo]) REFERENCES Drzewo([Id]) ON DELETE RESTRICT
);

INSERT INTO [Dokumenty]([Id],[IdKategoria],[IdDrzewo],[Aktywny],[DataDokumentu],[Numer],[Opis],[Kwota],[DaneA],[DaneB],[DaneC],[DaneD],[Blokada])
SELECT [Id],[IdKategoria],[IdDrzewo],[Aktywny],[DataDokumentu],[Numer],[Opis],[Kwota],[DaneA],[DaneB],[DaneC],[DaneD],[Blokada]
FROM [tmp_Dokumenty];

DROP TABLE IF EXISTS [tmp_Dokumenty];

-- Tablica Zdarzenie
ALTER TABLE [Zdarzenia] RENAME TO [tmp_Zdarzenia];

-- DROP TABLE [Zdarzenia]
CREATE TABLE IF NOT EXISTS [Zdarzenia]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdKategoria] integer NOT NULL,
  [IdDrzewo] integer NOT NULL,
  [DataZdarzenia] datetime NULL,
  [Nazwa] varchar(100) NULL,
  [Opis] text NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Zdarzenia_IdKategoria FOREIGN KEY([IdKategoria]) REFERENCES Kategoria([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Zdarzenia_IdDrzewo FOREIGN KEY([IdDrzewo]) REFERENCES Drzewo([Id]) ON DELETE RESTRICT
);

INSERT INTO [Zdarzenia]([Id],[IdKategoria],[IdDrzewo],[DataZdarzenia],[Nazwa],[Opis],[Blokada])
SELECT [Id],[IdKategoria],[IdDrzewo],[DataZdarzenia],[Nazwa],[Opis],[Blokada]
FROM [tmp_Zdarzenia];

DROP TABLE IF EXISTS [tmp_Zdarzenia];

-- Tablica Dane
ALTER TABLE [Dane] RENAME TO [tmp_Dane];

CREATE TABLE IF NOT EXISTS [Dane]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdKategoria] integer NOT NULL,
  [IdDrzewo] integer NOT NULL,
  [Typ] varchar(100) NULL,
  [Nazwa] text NOT NULL,
  [Wartosc] text NULL,
  [Uwagi] text NULL,
  [PlikZew] text NULL,
  [KatalogZew] text NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Dane_IdKategoria FOREIGN KEY([IdKategoria]) REFERENCES Kategoria([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Dane_IdDrzewo FOREIGN KEY([IdDrzewo]) REFERENCES Drzewo([Id]) ON DELETE RESTRICT
);

INSERT INTO [Dane]([Id],[IdKategoria],[IdDrzewo],[Typ],[Nazwa],[Wartosc],[Uwagi],[Blokada])
SELECT [Id],[IdKategoria],[IdDrzewo],[Typ],[Nazwa],[Wartosc],[Uwagi],[Blokada]
FROM [tmp_Dane];

DROP TABLE IF EXISTS [tmp_Dane];

DROP VIEW IF EXISTS V_DokumentyLinki;
CREATE VIEW IF NOT EXISTS [V_DokumentyLinki]
AS 
SELECT
  z.[IdDokument],
  COUNT(z.IdDokument) AS [IloscLinkow]
FROM [Linki] AS z
WHERE
  z.[IdDokument] IS NOT NULL
GROUP BY
  z.[IdDokument];

DROP VIEW IF EXISTS V_ZdarzeniaLinki;
CREATE VIEW IF NOT EXISTS [V_ZdarzeniaLinki]
AS 
SELECT
  z.[IdZdarzenie],
  COUNT(z.IdZdarzenie) AS [IloscLinkow]
FROM [Linki] AS z
WHERE
  z.[IdZdarzenie] IS NOT NULL
GROUP BY
  z.[IdZdarzenie];

  
DROP VIEW IF EXISTS V_DaneLinki;
CREATE VIEW IF NOT EXISTS [V_DaneLinki]
AS 
SELECT
  z.[IdDane],
  COUNT(z.[IdDane]) AS [IloscLinkow]
  FROM [Linki] AS z
WHERE
  z.[IdDane] IS NOT NULL
GROUP BY
  z.[IdDane];
  
UPDATE [Parametry] SET [WartoscS]='1-012' WHERE [Klucz]='Program::WersjaBazy';