-- Utworz załączniki
CREATE TABLE IF NOT EXISTS [Zalaczniki]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdDokument] integer NULL,
  [IdKontakt] integer NULL,
  [IdRozrachunek] integer NULL,
  [IdWplata] integer NULL,
  [Obraz] blob NULL,
  [NazwaPliku] varchar(256) NULL,
  [WielkoscB] integer NOT NULL DEFAULT 0
);

-- Dopisz z tablicy Dokumenty
INSERT INTO [Zalaczniki] ([IdDokument],[IdKontakt],[IdRozrachunek],[IdWplata],[Obraz],[NazwaPliku],[WielkoscB])
SELECT
  t.Id as [IdDokument],
  null as [IdKontakt],
  null as [IdRozrachunek],
  null as [IdWplata],
  t.Obraz as [Obraz],
  t.NazwaPliku as [NazwaPliku],
  t.WielkoscB  as [WielkoscB]
FROM [Dokumenty] AS t
WHERE
  (t.WielkoscB > 0);

-- Dopisz z tablicy Kontakty
INSERT INTO [Zalaczniki] ([IdDokument],[IdKontakt],[IdRozrachunek],[IdWplata],[Obraz],[NazwaPliku],[WielkoscB])
SELECT
  null as [IdDokument],
  t.Id as [IdKontakt],
  null as [IdRozrachunek],
  null as [IdWplata],
  t.Obraz as [Obraz],
  t.TypPliku as [NazwaPliku],
  t.WielkoscB  as [WielkoscB]
FROM [Kontakty] AS t
WHERE
  (t.WielkoscB > 0);

-- Dopisz z tablicy Rozrachunki
INSERT INTO [Zalaczniki] ([IdDokument],[IdKontakt],[IdRozrachunek],[IdWplata],[Obraz],[NazwaPliku],[WielkoscB])
SELECT
  null as [IdDokument],
  null as [IdKontakt],
  t.Id as [IdRozrachunek],
  null as [IdWplata],
  t.Obraz as [Obraz],
  t.NazwaPliku as [NazwaPliku],
  t.WielkoscB  as [WielkoscB]
FROM [Rozrachunki] AS t
WHERE
  (t.WielkoscB > 0);

-- Dopisz z tablicy Wplaty
INSERT INTO [Zalaczniki] ([IdDokument],[IdKontakt],[IdRozrachunek],[IdWplata],[Obraz],[NazwaPliku],[WielkoscB])
SELECT
  null as [IdDokument],
  null as [IdKontakt],
  null as [IdRozrachunek],
  t.Id as [IdWplata],
  t.Obraz as [Obraz],
  t.NazwaPliku as [NazwaPliku],
  t.WielkoscB  as [WielkoscB]
FROM [Wplaty] AS t
WHERE
  (t.WielkoscB > 0);

-- Tablica Dokumenty
ALTER TABLE [Dokumenty] RENAME TO [tmp_Dokumenty];

CREATE TABLE IF NOT EXISTS [Dokumenty]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdKategoria] integer NOT NULL,
  [IdDrzewo] integer NOT NULL,
  [Aktywny] integer NOT NULL DEFAULT 1,
  [DataDokumentu] datetime NULL,
  [Numer] varchar(50) NULL,
  [Opis] text NULL,
  [Kwota] real NULL,
  [DaneA] text NULL,
  [DaneB] text NULL,
  [DaneC] text NULL,
  [DaneD] text NULL,
  [PlikZew] text NULL,
  [KatalogZew] text NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Dokumenty_IdKategoria FOREIGN KEY([IdKategoria]) REFERENCES Kategoria([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Dokumenty_IdDrzewo FOREIGN KEY([IdDrzewo]) REFERENCES Drzewo([Id]) ON DELETE RESTRICT
);

INSERT INTO [Dokumenty]([Id],[IdKategoria],[IdDrzewo],[Aktywny],[DataDokumentu],[Numer],[Opis],[Kwota],[DaneA],[DaneB],[DaneC],[DaneD],[PlikZew],[KatalogZew],[Blokada])
SELECT [Id],[IdKategoria],[IdDrzewo],1,[DataDokumentu],[Numer],[Opis],[Kwota],[DaneA],[DaneB],[DaneC],[DaneD],[PlikZew],[KatalogZew],[Blokada]
FROM [tmp_Dokumenty];

DROP TABLE IF EXISTS [tmp_Dokumenty];

-- Tablica Kontakty
ALTER TABLE [Kontakty] RENAME TO [tmp_Kontakty];

CREATE TABLE IF NOT EXISTS [Kontakty]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdKategoria] integer NOT NULL,
  [IdDrzewo] integer NOT NULL,
  [Aktywny] integer NOT NULL DEFAULT 1,
  [Nazwa] varchar(100) NOT NULL,
  [Firma] varchar(100) NULL,
  [Stanowisko] varchar(50) NULL,
  [Skojarzenie] text NULL,
  [TelGlowny] varchar(60) NULL,
  [TelPomocniczy] varchar(60) NULL,
  [Email] varchar(120) NULL,
  [Strona] varchar(200) NULL,
  [Komunikator] varchar(100) NULL,
  [Adres] text NULL,
  [DataUrodzenia] datetime NULL,
  [Uwagi] text NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Kontakty_IdKategoria FOREIGN KEY([IdKategoria]) REFERENCES Kategoria([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Kontakty_IdDrzewo FOREIGN KEY([IdDrzewo]) REFERENCES Drzewo([Id]) ON DELETE RESTRICT
);

INSERT INTO [Kontakty] ([Id],[IdKategoria],[IdDrzewo],[Aktywny],[Nazwa],[Stanowisko],[Skojarzenie],[TelGlowny],[TelPomocniczy],[Email],[Strona],[Komunikator],[Adres],[DataUrodzenia],[Uwagi],[Blokada])
SELECT [Id],[IdKategoria],[IdDrzewo],1,[Nazwa],[Stanowisko],[Skojarzenie],[TelGlowny],[TelPomocniczy],[Email],[Strona],[Komunikator],[Adres],[DataUrodzenia],[Uwagi],[Blokada]
FROM [tmp_Kontakty];

DROP TABLE IF EXISTS [tmp_Kontakty];

-- Tablica Rozrachunki
ALTER TABLE [Rozrachunki] RENAME TO [tmp_Rozrachunki];

CREATE TABLE IF NOT EXISTS [Rozrachunki]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdKategoria] integer NOT NULL,
  [IdDrzewo] integer NOT NULL,
  [IdKonto] integer NULL,
  [Aktywny] integer NOT NULL DEFAULT 1,
  [Tytulem] text NULL,
  [DataPlatnosci] datetime NOT NULL,
  [Kwota] real NOT NULL,
  [CzyZlecona] integer NOT NULL DEFAULT 0,
  [CzyZaplacona] integer NOT NULL DEFAULT 0,
  [Opis] text NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Rozrachunki_IdKategoria FOREIGN KEY([IdKategoria]) REFERENCES Kategoria([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Rozrachunki_IdDrzewo FOREIGN KEY([IdDrzewo]) REFERENCES Drzewo([Id]) ON DELETE RESTRICT
);

INSERT INTO [Rozrachunki] ([Id],[IdKategoria],[IdDrzewo],[IdKonto],[Aktywny],[Tytulem],[DataPlatnosci],[Kwota],[CzyZlecona],[CzyZaplacona],[Opis],[Blokada])
SELECT [Id],[IdKategoria],[IdDrzewo],[IdKonto],1,[Tytulem],[DataPlatnosci],[Kwota],[CzyZlecona],[CzyZaplacona],[Opis],[Blokada]
FROM [tmp_Rozrachunki];

DROP TABLE IF EXISTS [tmp_Rozrachunki];

-- Tablica Wplaty
ALTER TABLE [Wplaty] RENAME TO [tmp_Wplaty];

CREATE TABLE IF NOT EXISTS [Wplaty]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdRozrachunek] integer NOT NULL,
  [DataWplaty] datetime NOT NULL,
  [Kwota] real NOT NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Wplaty_IdRozrachunek FOREIGN KEY([IdRozrachunek]) REFERENCES Rozrachunki([Id]) ON DELETE RESTRICT
);

INSERT INTO [Wplaty] ([Id],[IdRozrachunek],[DataWplaty],[Kwota],[Blokada])
SELECT [Id],[IdRozrachunek],[DataWplaty],[Kwota],[Blokada]
FROM [tmp_Wplaty];

DROP TABLE IF EXISTS [tmp_Wplaty];

DROP VIEW IF EXISTS V_DokumentyZalaczniki;
CREATE VIEW IF NOT EXISTS [V_DokumentyZalaczniki]
AS 
SELECT
  z.[IdDokument],
  COUNT(z.IdDokument) AS [IloscZalacznikow]
FROM [Zalaczniki] AS z
WHERE
  z.[IdDokument] IS NOT NULL
GROUP BY
  z.[IdDokument];
  
DROP VIEW IF EXISTS V_KontaktyZalaczniki;
CREATE VIEW IF NOT EXISTS [V_KontaktyZalaczniki]
AS 
SELECT
  z.[IdKontakt],
  COUNT(z.[IdKontakt]) AS [IloscZalacznikow]
FROM [Zalaczniki] AS z
WHERE
  z.[IdKontakt] IS NOT NULL
GROUP BY
  z.[IdKontakt];
  
DROP VIEW IF EXISTS V_RozrachunkiZalaczniki;
CREATE VIEW IF NOT EXISTS [V_RozrachunkiZalaczniki]
AS 
SELECT
  z.[IdRozrachunek],
  COUNT(z.[IdRozrachunek]) AS [IloscZalacznikow]
FROM [Zalaczniki] AS z
WHERE
  z.[IdRozrachunek] IS NOT NULL
GROUP BY
  z.[IdRozrachunek];
  
DROP VIEW IF EXISTS V_WplatyZalaczniki;
CREATE VIEW IF NOT EXISTS [V_WplatyZalaczniki]
AS 
SELECT
  z.[IdWplata],
  COUNT(z.[IdWplata]) AS [IloscZalacznikow]
FROM [Zalaczniki] AS z
WHERE
  z.[IdWplata] IS NOT NULL
GROUP BY
  z.[IdWplata];   
 
UPDATE [Parametry] SET [WartoscS]='1-006' WHERE [Klucz]='Program::WersjaBazy';