ALTER TABLE [Kontakty] RENAME TO [tmp_Kontakty];

CREATE TABLE IF NOT EXISTS [Kontakty]
(
  [Id] integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  [IdKategoria] integer NOT NULL,
  [IdDrzewo] integer NOT NULL,
  [Aktywny] integer NOT NULL DEFAULT 1,
  [Nazwa] varchar(100) NOT NULL,
  [Firma] varchar(100) NULL,
  [Stanowisko] varchar(50) NULL,
  [Skojarzenie] text NULL,
  [Telefon1] varchar(60) NULL,
  [Telefon2] varchar(60) NULL,
  [Telefon3] varchar(60) NULL,
  [Telefon4] varchar(60) NULL,
  [Email1] varchar(120) NULL,
  [Email2] varchar(120) NULL,
  [Strona] varchar(200) NULL,
  [Komunikator] varchar(100) NULL,
  [Adres] text NULL,
  [DataUrodzenia] datetime NULL,
  [Uwagi] text NULL,
  [Blokada] integer NOT NULL DEFAULT 0,
  CONSTRAINT FK_Kontakty_IdKategoria FOREIGN KEY([IdKategoria]) REFERENCES Kategoria([Id]) ON DELETE RESTRICT,
  CONSTRAINT FK_Kontakty_IdDrzewo FOREIGN KEY([IdDrzewo]) REFERENCES Drzewo([Id]) ON DELETE RESTRICT
);

-- Dopisz z tablicy Konta
INSERT INTO [Kontakty] ([Id],[IdKategoria],[IdDrzewo],[Aktywny],[Nazwa],[Firma],[Stanowisko],[Skojarzenie],[Telefon1],[Telefon2],[Telefon3],[Telefon4],[Email1],[Email2],[Strona],[Komunikator],[Adres],[DataUrodzenia],[Uwagi],[Blokada])
SELECT
t.Id,
t.IdKategoria,
t.IdDrzewo,
t.Aktywny,
t.Nazwa,
t.Firma,
t.Stanowisko,
t.Skojarzenie,
t.TelGlowny,
t.TelPomocniczy,
null,
null,
t.Email,
null,
t.Strona,
t.Komunikator,
t.Adres,
t.DataUrodzenia,
t.Uwagi,
t.Blokada
FROM [tmp_Kontakty] AS t;

DROP TABLE IF EXISTS [tmp_Kontakty];

UPDATE [Parametry] SET [WartoscS]='1-011' WHERE [Klucz]='Program::WersjaBazy';